#!/bin/sh
#
#zenity --info --title="Demo Progress Script" --text "This script shows how Zenity creates a progress bar."
#
#find /home/phil | zenity --progress --pulsate --auto-close --auto-kill --text "Working..."
#
#zenity --info --title="Job complete" --text "The demo script is now complete."

startApps ()
        { 
	export OOO_FORCE_DESKTOP=gnome
	conky &
	#applet for network connectivity
	nm-applet --nb-disabled &
	# Auto-mounting drives
	gnome-volume-manager &
	# multimedia keys - power manager
	gnome-settings-daemon & 
	gnome-power-manager &
	# stuff from GNOME 
	/usr/lib/gnome-volume-manager/gnome-volume-manager --sm-disable &
	#gsynaptics-init --sm-disable
	#smart-notifier
	#compiz
	/usr/bin/compiz.real --ignore-desktop-hints --loose-binding ccp &
	# To set the background image
	nitrogen --restore &
	#Trayer and its appearance
	trayer --transparent true --expand true --alpha 255 --widthtype request --SetDockType true --edge bottom --align right &
	# OR use pypanel
	#pypanel &
	# OR use stalonetray
	#stalonetray -t -i 36 &
	#tablaunch -x 20 -fg "#CCCCCC" -pfg "#CCCCCC" -sfg "#FFFFFF" -bg "#31353A" --pulldown 0 -t &
	#tablaunch -x 350 -fg "#CCCCCC" -pfg "#CCCCCC" -sfg "#FFFFFF" -bg "#31353A" --pulldown 0 -t &
	#tablaunch -x 300 -fg "#CCCCCC" -pfg "#CCCCCC" -sfg "#FFFFFF" -bg "#31353A" --pulldown 0 --iconMaskOff &
	tablaunch -x 300 -fg "#CCCCCC" -pfg "#CCCCCC" -sfg "#FFFFFF" -bg "#31353A" --pulldown 0 -t &
	#Progs etc... starting automatically
	(sleep 6 && pidgin) &
	#(sleep 6 && skype) &
	(sleep 7 && firefox) &
	#(sleep 5 && evolution) &
	#(sleep 7 && tint) &
	#(sleep 9 && gmrun) &
	}
startApps
#startApps | zenity --progress --pulsate --auto-close --auto-kill --text "Starting apps..."
