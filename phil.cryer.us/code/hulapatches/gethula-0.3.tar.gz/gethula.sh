#!/usr/local/bin/bash
#
# Modify to suit your environment
##########################################################
BASE_DIR=/root/bin/gethula
BUILD_DIR=/root/installers
AUTOGEN_PREFIX=/usr/local/hula-test
#AUTOGEN_PREFIX=/usr/local/hula
SMTP=26
DNS=192.168.1.3 
DOMAIN=cryer.us
START_TIME=`date`
# mysql-`date +%Y-%m-%d`
##########################################################
#
if [ ! "$BASE_DIR" ]
then
  echo "BASE_DIR not defined!" >&2
  exit 1
fi
if [ ! "$BUILD_DIR" ]
then
  echo "BUILD_DIR not defined!" >&2
  exit 1
fi
if [ ! "$AUTOGEN_PREFIX" ]
then
  echo "AUTOGEN_PREFIX not defined!" >&2
  exit 1
fi
if [ ! "$SMTP" ]
then
  echo "SMTP not defined!" >&2
  exit 1
fi
if [ ! "$DNS" ]
then
  echo "DNS not defined!" >&2
  exit 1
fi
if [ ! "$DOMAIN" ]
then
  echo "DOMAIN not defined!" >&2
  exit 1
fi
#
clear
echo ""
echo " +-----------------------------------------------------+"
echo " |  Hulaget - checks out and builds current Hula code  |"
echo " +-----------------------------------------------------+"
echo ""
#
echo "  * Changing to build directory..."
cd $BUILD_DIR
#
echo "  * Cleaning old tree..."
rm -rf trunk
#rm -f $BUILD_DIR/trunk/hula/src/libs/xpl/resolve.c
#rm -f $BUILD_DIR/trunk/hula/autogen.sh
#
echo "  * Staring SVN checkout..."
$BASE_DIR/svn.exp
#
cd trunk/hula
#
OS=`uname`
if [ $OS = "FreeBSD" ]; then
        echo " * Target system is $OS, patching Hula source..."
        patch -p0 < $BASE_DIR/patches/autogen.diff
        patch -p0 < $BASE_DIR/patches/resolve.diff
        patch -p0 < $BASE_DIR/patches/remove-sysinfo-calls.diff
else
        echo " * Target system is $OS, no patching neccessary."
fi
#
./autogen.sh --prefix=$AUTOGEN_PREFIX
#
make
#
make install
#
cd $AUTOGEN_PREFIX/sbin
./hulasetup --smtp=$SMTP --dns=$DNS --domain=$DOMAIN
#
echo ""
REVISION=`grep revision $BUILD_DIR/trunk/hula/.svn/entries > build_number | cut -c 14,15,16 build_number`
echo "  * Install of build "$REVISION" complete."
mv build_number $AUTOGEN_PREFIX
echo "  * To run hula:
echo "    	cd $AUTOGEN_PREFIX/sbin"
echo "		./hulamanager"
echo "  * Hulaget complete, ran from:"
echo "		$START_TIME to"
echo "		`date`" 
echo " +----------------------------------------------------+"
#
exit 0

