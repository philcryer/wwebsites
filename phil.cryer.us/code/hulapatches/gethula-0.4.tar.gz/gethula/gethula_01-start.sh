#!/usr/local/bin/bash
#
##########################################################
START_TIME=`date`
#
if [ ! "$BASE_DIR" ]
then
  echo "BASE_DIR not defined!" >&2
  exit 1
fi
if [ ! "$BUILD_DIR" ]
then
  echo "BUILD_DIR not defined!" >&2
  exit 1
fi
if [ ! "$AUTOGEN_PREFIX" ]
then
  echo "AUTOGEN_PREFIX not defined!" >&2
  exit 1
fi
if [ ! "$SMTP" ]
then
  echo "SMTP not defined!" >&2
  exit 1
fi
if [ ! "$DNS" ]
then
  echo "DNS not defined!" >&2
  exit 1
fi
if [ ! "$DOMAIN" ]
then
  echo "DOMAIN not defined!" >&2
  exit 1
fi
#
clear
echo ""
echo " +-----------------------------------------------------+"
echo " | Gethula_start.sh - gets & builds current Hula code  |"
echo " +-----------------------------------------------------+"
echo ""
#
echo "	Reading etc/gethula.conf..."
source etc/gethula.conf
#
echo "	Changing to build directory..."
cd $BUILD_DIR
if [ "$CLEAN_TREE" = "yes" ]
then
	echo "	Cleaning old tree..."
	rm -rf hula
fi
#
echo ""
echo " +-----------------------------------------------------+"
echo ""
echo "	Staring SVN checkout..."
echo ""
$BASE_DIR/bin/expectscript
#
cd hula
#
echo ""
echo " +-----------------------------------------------------+"
echo ""
echo "	Patching Hula, if required..."
OS=`uname`
if [ $OS = "FreeBSD" ]; then
        echo "	Target system is $OS, patching Hula source..."
       patch -p0 < $BASE_DIR/patches/autogen.diff
       patch -p0 < $BASE_DIR/patches/resolve.diff
       # the following patch no longer needed for revs > 240
       # patch -p0 < $BASE_DIR/patches/remove-sysinfo-calls.diff
else
        echo "	Target system is $OS, no patching neccessary."
fi
#
echo ""
echo " +-----------------------------------------------------+"
echo ""
echo "  Configuring Hula..."
./autogen.sh --prefix=$AUTOGEN_PREFIX
#
echo ""
echo " +-----------------------------------------------------+"
echo ""
echo "  Making Hula..."
make
REVISION=`grep revision $BUILD_DIR/hula/.svn/entries > build_number | cut -c 14,15,16 revision_number`
echo ""
#
echo " +-----------------------------------------------------+"
echo " | 		Make Complete 	  		     |"
echo " +-----------------------------------------------------+"
echo ""
echo "	Barring any errors, build r"$REVISION" is compiled"
echo "  and ready to be installed."
echo ""
echo "	Gethula_start complete, running from:"
echo "	  $START_TIME to `date`" 
echo ""
echo "	To complete installation, STOP and BACKUP any" 
echo "  current Hula servers, and then finish the Hula"
echo "  install with:"
echo "		./gethula_finish.sh"
echo ""
echo " +----------------------------------------------------+"
exit 0
