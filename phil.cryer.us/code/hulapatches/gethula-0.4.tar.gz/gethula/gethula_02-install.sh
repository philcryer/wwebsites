#!/usr/local/bin/bash
#
#
clear
echo ""
echo " +-----------------------------------------------------+"
echo " |  gethula_install.sh - installs and configures Hula  |"
echo " +-----------------------------------------------------+"
echo ""
echo "	Installing Hula..."
make install
echo ""
echo " +----------------------------------------------------+"
echo ""
echo "	Configuring Hula..."
cd $AUTOGEN_PREFIX/sbin"
./hulasetup   --smtp=$SMTP --dns=$DNS --domain=$DOMAIN        \"
cp revision_number $AUTOGEN_PREFIX"
echo ""
echo "  gethula_install complete. To run Hula server:"
echo "    cd $AUTOGEN_PREFIX/sbin"
echo "    ./hulamanager -s"
echo ""
echo " +----------------------------------------------------+"
#
exit 0

